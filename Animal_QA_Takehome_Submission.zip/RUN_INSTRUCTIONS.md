# Quick Run & Execution Instructions

This submission is designed to be completely turnkey. You can run the entire automated test suite with a single command.

---

## 1. Prerequisites
- **Python:** 3.9 or higher (tested on Python 3.9 – 3.14)
- Required libraries: `pytest` and `requests` (listed in `requirements.txt`)

---

## 2. Quick Setup

```bash
# Option A: Standard pip install
pip install -r requirements.txt

# Option B: If using a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## 3. Running the Tests

### Option A: One-Line Test Runner (Recommended)
Simply run the bundled script:

```bash
./run_tests.sh
```

**What `./run_tests.sh` does automatically:**
1. Checks dependencies and ensures `pytest` and `requests` are available.
2. Checks if `server.py` is running on port `18080`; if not, spins it up in the background (`python3 server.py --reset`).
3. Executes all 27 automated tests with readable failure traces.
4. Generates a complete test report at `test_report.txt`.
5. Automatically terminates the background test server on completion.

---

### Option B: Running via Pytest Directly

If you prefer to start the server manually:

**Terminal 1 (Start Server):**
```bash
python3 server.py --reset
```

**Terminal 2 (Run Pytest):**
```bash
# Run the full specification suite (displays clear failure assertions for surfaced bugs)
pytest -v

# Run only the passing contract/baseline tests (14 passed)
pytest -v -m "not bug"

# Run specific functional suites
pytest -v tests/test_webhooks.py
pytest -v tests/test_reconciliation.py
pytest -v tests/test_concurrency.py
pytest -v tests/test_trials.py
pytest -v tests/test_subscriptions.py
```

---

## 4. Understanding the Test Results

The suite contains **27 automated tests**:

- **14 Tests PASS (Green):**
  Validates baseline functionality, happy paths (trial creation, successful webhook activation, reconciliation of pending records), schema validations, and security key enforcement on `/api/reconcile`.

- **13 Tests FAIL (Red):**
  Per the assignment instructions (*"Do not modify server.py to make your tests pass. The point is to test the supplied system and surface defects."*), these tests assert the exact business rules from the prompt. Their failures prove that the suite successfully catches all 8 defects documented in `BUGS.md`:
  - **BUG-001 (P0):** Missing webhook signature verification (`X-Signature` header ignored).
  - **BUG-002 (P0):** Active subscriptions downgraded by out-of-order `FAILED` webhooks.
  - **BUG-003 (P0):** Reconciliation failing to recover `FAILED` trials when provider reports `SUCCESS`.
  - **BUG-004 (P1):** Duplicate payment records created on webhook retries for the same `provider_txn_id`.
  - **BUG-005 (P1):** Duplicate live trials created on repeated and concurrent requests.
  - **BUG-006 (P1):** Trial creation accepting non-positive (`<= 0`) and boolean amounts.
  - **BUG-007 (P2):** `GET /api/subscriptions/{user_id}` masking active subscriptions with later pending trials, and 404 on trailing slash.
  - **BUG-008 (P2):** Missing concurrency synchronization (`DB_LOCK` unused) and lack of database integrity constraints.

---

## 5. Artifact Directory Guide

| File | Purpose |
| :--- | :--- |
| **`RUN_INSTRUCTIONS.md`** | This run guide. |
| **`TEST_STRATEGY.md`** | Full risk-based test strategy (P0/P1/P2 matrix, async lifecycle, telemetry). |
| **`BUGS.md`** | Detailed defect report with reproduction steps, evidence, and root-cause fixes. |
| **`README_SUBMISSION.md`**| Detailed engineering & release answers (CI/CD, flakiness, metrics, triage). |
| **`TEST_REPORT.md`** | Summary breakdown of the 27 tests and defect traceability matrix. |
| **`test_report.txt`** | Full console execution log generated from the latest run. |
| **`run_tests.sh`** | Turnkey runner script. |
| **`server.py`** | Original, unmodified challenge server. |
| **`tests/`** | The 5 automated test modules (`trials`, `webhooks`, `reconciliation`, `concurrency`, `subscriptions`). |
