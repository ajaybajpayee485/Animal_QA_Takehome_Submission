#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

echo "================================================================="
echo " Animall QA Challenge: Subscription Reliability Test Suite"
echo "================================================================="

# 1. Check Python dependencies
echo "[+] Checking Python dependencies..."
if ! python3 -c "import pytest, requests" >/dev/null 2>&1; then
    echo "[+] Installing missing packages..."
    python3 -m pip install -r requirements.txt --break-system-packages --quiet || true
fi

# 2. Check if server.py is running; if not, start it in background
SERVER_PID=""
if ! curl -s http://127.0.0.1:18080/health >/dev/null 2>&1; then
    echo "[+] Starting local test server (server.py --reset)..."
    python3 server.py --reset >/dev/null 2>&1 &
    SERVER_PID=$!
    # Wait for server to be ready
    for i in {1..30}; do
        if curl -s http://127.0.0.1:18080/health >/dev/null 2>&1; then
            break
        fi
        sleep 0.1
    done
fi

cleanup() {
    if [ -n "$SERVER_PID" ]; then
        echo "[+] Terminating test server (PID $SERVER_PID)..."
        kill -9 "$SERVER_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT

echo "[+] Running test suite via pytest..."
echo "-----------------------------------------------------------------"

# Run pytest and capture report
set +e
if [ $# -eq 0 ]; then
    echo "[+] Executing: python3 -m pytest -v --tb=short"
    python3 -m pytest -v --tb=short | tee test_report.txt
    EXIT_CODE=$?
else
    echo "[+] Executing: python3 -m pytest $@"
    python3 -m pytest "$@" | tee test_report.txt
    EXIT_CODE=$?
fi
set -e

echo "-----------------------------------------------------------------"
echo "[+] Test run completed."
echo "[+] Full test report written to: $DIR/test_report.txt"
echo "================================================================="

exit $EXIT_CODE
