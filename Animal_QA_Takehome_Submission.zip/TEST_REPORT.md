# Automated Test Execution Report

**Project:** Animall QA Takehome — Subscription Reliability Challenge  
**Execution Environment:** Linux (Ubuntu), Python 3.14.4, Pytest 9.0.2  
**Target API:** `http://127.0.0.1:18080` (System Under Test: unmodified `server.py`)  
**Test Isolation:** Automatic database reset (`POST /api/admin/reset`) before every test  

---

## 1. Execution Summary

| Metric | Result |
| :--- | :--- |
| **Total Test Cases** | **27** |
| **Passing Tests (Contract / Baseline Verification)** | **14 (51.9%)** |
| **Failing Tests (Defect Verification / Bug Catchers)** | **13 (48.1%)** |
| **Execution Duration** | **0.84 seconds** |
| **Test Suites** | 5 (`trials`, `webhooks`, `reconciliation`, `concurrency`, `subscriptions`) |

> **Note on Failures:** As instructed in the challenge requirements (*"Do not modify server.py to make your tests pass. The point is to test the supplied system and surface defects."*), all 13 test failures are intentional assertions against the business specification that successfully detected the flaws in `server.py`.

---

## 2. Test Results by Suite

### Suite 1: Trial Creation (`tests/test_trials.py`)
- ✅ `test_create_trial_happy_path_monthly` — PASSED: Creates monthly trial in `PENDING` state with positive amount.
- ✅ `test_create_trial_happy_path_yearly` — PASSED: Creates yearly trial in `PENDING` state.
- ✅ `test_create_trial_rejects_missing_fields` — PASSED: Returns 400 Bad Request when required fields are missing.
- ✅ `test_create_trial_rejects_invalid_plan` — PASSED: Returns 400 Bad Request when plan is not monthly/yearly.
- ❌ `test_create_trial_duplicate_live_prevention` — **FAILED**: Surfaces **BUG-005** (Repeated client requests created 2 live trials for same user/plan).
- ❌ `test_create_trial_rejects_negative_or_zero_amount` — **FAILED**: Surfaces **BUG-006** (Accepted `amount=0` and `amount=-100` with HTTP 201).
- ❌ `test_create_trial_rejects_boolean_amount` — **FAILED**: Surfaces **BUG-006** (Accepted `amount=true` as integer 1 with HTTP 201).

### Suite 2: Payment Webhooks (`tests/test_webhooks.py`)
- ✅ `test_webhook_payment_success_activates_trial` — PASSED: `SUCCESS` webhook transitions trial to `ACTIVE` and records payment.
- ✅ `test_webhook_payment_failed_marks_trial_failed` — PASSED: `FAILED` webhook transitions trial to `FAILED`.
- ✅ `test_webhook_unknown_order_makes_no_state_change` — PASSED: Unknown order webhook returns 200 ignored without creating state.
- ✅ `test_webhook_invalid_status_rejected` — PASSED: Invalid provider status returns 400 Bad Request.
- ❌ `test_webhook_missing_signature_rejected` — **FAILED**: Surfaces **BUG-001** (Webhook without `X-Signature` header was accepted with HTTP 200).
- ❌ `test_webhook_invalid_signature_rejected` — **FAILED**: Surfaces **BUG-001** (Webhook with invalid signature was accepted with HTTP 200).
- ❌ `test_webhook_out_of_order_failed_never_downgrades` — **FAILED**: Surfaces **BUG-002** (Active trial was downgraded to `FAILED` by out-of-order webhook).
- ❌ `test_webhook_out_of_order_pending_never_downgrades` — **FAILED**: Surfaces **BUG-002** (Active trial was downgraded to `PENDING` by out-of-order webhook).
- ❌ `test_webhook_idempotency_duplicate_success_callbacks` — **FAILED**: Surfaces **BUG-004** (Duplicate callback created 2 payment records for same `provider_txn_id`).

### Suite 3: Reconciliation (`tests/test_reconciliation.py`)
- ✅ `test_reconcile_recovers_pending_to_active` — PASSED: Recovers `PENDING` trial to `ACTIVE` on provider `SUCCESS`.
- ✅ `test_reconcile_unauthorized_missing_internal_key` — PASSED: Returns 401 when `X-Internal-Key` is missing or invalid.
- ✅ `test_reconcile_unknown_order_returns_404` — PASSED: Returns 404 `order_not_found` for unknown orders.
- ✅ `test_reconcile_idempotency_active_trial_not_downgraded` — PASSED: Does not downgrade already `ACTIVE` trials.
- ❌ `test_reconcile_recovers_failed_to_active` — **FAILED**: Surfaces **BUG-003** (Failed to recover `FAILED` trial to `ACTIVE` on provider `SUCCESS`).

### Suite 4: Concurrency & Race Conditions (`tests/test_concurrency.py`)
- ❌ `test_concurrent_trial_creation_single_live_trial` — **FAILED**: Surfaces **BUG-005** (Concurrent requests created 5 duplicate live trials for same user/plan).
- ❌ `test_concurrent_webhooks_race_condition` — **FAILED**: Surfaces **BUG-004** (Concurrent duplicate webhooks created 5 duplicate payment records for same `provider_txn_id`).

### Suite 5: Subscriptions (`tests/test_subscriptions.py`)
- ✅ `test_get_subscription_reflects_active_state` — PASSED: Returns `ACTIVE` trial for user.
- ✅ `test_get_subscription_non_existent_user_returns_404` — PASSED: Returns 404 for unknown user.
- ❌ `test_get_subscription_not_masked_by_subsequent_pending` — **FAILED**: Surfaces **BUG-007** (Subsequent pending trial masked active subscription).
- ❌ `test_get_subscription_trailing_slash_resilience` — **FAILED**: Surfaces **BUG-007** (Trailing slash returned 404 instead of 200).

---

## 3. Defect-to-Test Traceability Matrix

| Defect ID | Defect Title | Catching Automated Tests | Violated Rule |
| :--- | :--- | :--- | :--- |
| **BUG-001** | Missing Webhook Signature Verification | `test_webhook_missing_signature_rejected`, `test_webhook_invalid_signature_rejected` | Rule 9 |
| **BUG-002** | Out-of-Order Webhook Downgrades Active Trial | `test_webhook_out_of_order_failed_never_downgrades`, `test_webhook_out_of_order_pending_never_downgrades` | Rule 6 |
| **BUG-003** | Reconciliation Fails to Recover FAILED Trial | `test_reconcile_recovers_failed_to_active` | Rule 12 |
| **BUG-004** | Duplicate Payment Records on Duplicate Webhooks | `test_webhook_idempotency_duplicate_success_callbacks`, `test_concurrent_webhooks_race_condition` | Rules 7, 8 |
| **BUG-005** | Duplicate Live Trials on Repeat & Concurrency | `test_create_trial_duplicate_live_prevention`, `test_concurrent_trial_creation_single_live_trial` | Rules 1, 14 |
| **BUG-006** | Acceptance of Non-Positive & Boolean Amounts | `test_create_trial_rejects_negative_or_zero_amount`, `test_create_trial_rejects_boolean_amount` | Rule 2 |
| **BUG-007** | Stale Pending Masks Active Subscription & Slash Bug | `test_get_subscription_not_masked_by_subsequent_pending`, `test_get_subscription_trailing_slash_resilience` | Contract |
| **BUG-008** | Unused Lock and Missing Schema Constraints | `test_concurrent_webhooks_race_condition`, direct DB inspection | Rules 8, 14 |
