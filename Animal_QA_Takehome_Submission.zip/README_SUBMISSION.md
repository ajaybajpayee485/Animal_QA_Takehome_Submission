# QA Take-Home Submission — Subscription Reliability Challenge

This repository contains the complete QA test suite, test strategy, bug reports, and engineering analysis for the Animall Subscription Reliability Challenge.

---

## 1. Executive Overview of Deliverables

- **`TEST_STRATEGY.md`**: Risk-based test strategy covering threat modeling, P0/P1/P2 scenario categorization, concurrency, asynchronous payment lifecycle, data invariants, and post-release observability.
- **`BUGS.md`**: Formal defect reports for 8 identified bugs (including 3 Critical P0 vulnerabilities), complete with curl reproduction steps, expected vs. actual behaviors, evidence, and root-cause analysis.
- **Automated Test Suite (`tests/`)**: 22 automated end-to-end and integration tests written in Python `pytest`, featuring business state verification, direct SQLite invariant assertions, concurrency race testing, and automated test isolation.
- **`run_tests.sh`**: One-line script to install dependencies, run the test suite, and generate human-readable reports.

---

## 2. Engineering & Release Thinking

### 2.1. How would you run this suite in CI/CD?
In a modern CI/CD pipeline (e.g., GitHub Actions or GitLab CI):

1. **Pull Request (PR) Pre-Merge Gate (Fast Feedback - < 2 min):**
   - **Pipeline Stage:** Linting (`ruff`/`flake8`), unit tests, and the **P0/P1 API regression suite**.
   - **Ephemeral Test Environment:** Spin up an isolated containerized service instance with an empty, seeded test database (SQLite in-memory or PostgreSQL test container).
   - **Execution:** Run `pytest tests/ -m "p0 or p1"` in parallel using `pytest-xdist`.
   - **Rule:** 100% pass rate required to merge.

2. **Nightly / Pre-Release Staging Regression Gate:**
   - **Pipeline Stage:** Full test suite including concurrency stress tests (100 parallel workers), chaos testing (simulated network latency/timeouts on mock payment gateway), and edge cases.
   - **Artifacts:** Store JUnit XML reports, Allure test dashboards, and server error logs.

3. **Post-Deployment Smoke Tests (Continuous Delivery):**
   - Run non-destructive synthetic smoke tests against staging and production (verifying health checks, internal key authorization, and mock order lifecycle).

---

### 2.2. Which tests should block a production release?
The following test suites must be **hard release blockers**:

1. **Security & Authorization Gate (P0):**
   - Missing or invalid webhook signature (`X-Signature`) rejection (`HTTP 401`).
   - Unauthorized access to reconciliation and administrative endpoints (`HTTP 401`).
2. **State Monotonicity & Downgrade Prevention Gate (P0):**
   - Late/out-of-order `FAILED` or `PENDING` webhooks must **never** downgrade an already `ACTIVE` subscription.
3. **Financial & Idempotency Gate (P0):**
   - At-least-once provider callback retries must not produce duplicate records in the `payments` table or trigger duplicate charges.
   - Concurrency tests ensuring that duplicate clicks/requests cannot create multiple live trials for the same user and plan.
4. **Reconciliation Self-Healing Gate (P0):**
   - Reconciliation must recover both `PENDING` and prematurely `FAILED` trials when provider status is `SUCCESS`.

*Non-blocking for release (P2/Minor):* Minor cosmetic error message formatting, edge-case URL trailing slashes (can be hotfixed post-release if core transaction flow is protected).

---

### 2.3. How would you prevent flaky tests?
Flakiness in asynchronous payment testing typically stems from timing assumptions, state leakage, and shared resources:

1. **Deterministic Test Isolation (No Shared State):**
   - Use dynamic, unique IDs for every test run (e.g., `user_id = f"user_{uuid.uuid4().hex[:8]}"`).
   - Execute an administrative database reset (`POST /api/admin/reset`) before every test function via pytest fixture.
2. **Eliminate Arbitrary `time.sleep()` Calls:**
   - Replace static sleep delays with polling assertions with timeouts (e.g., polling `GET /api/subscriptions/{user_id}` until status updates or a 5-second deadline expires).
3. **Controlled Concurrency & Explicit Barriers:**
   - When testing race conditions, use `threading.Barrier` or `concurrent.futures` to ensure all parallel threads release their HTTP requests at the exact same instant, eliminating thread-scheduling skew.
4. **Mock External Provider Jitter in Integration Tests:**
   - Use an in-process mock server (e.g., WireMock or `responses`) to simulate gateway latency, drops, and out-of-order delivery deterministically.

---

### 2.4. Production Debugging: `provider = SUCCESS` but app status = `PENDING`
If production monitoring flags an order where the payment gateway succeeded but the internal subscription remains `PENDING`, follow this systematic triage hierarchy:

1. **Step 1: Check Payment Webhook Ingestion Logs:**
   - Did our API gateway / load balancer receive the webhook from the provider?
   - Search ingress logs for `POST /api/webhooks/payment` with the given `order_id` or gateway event ID.
   - *If missing:* Gateway callback was dropped, blocked by firewall/WAF, or webhook URL was misconfigured at provider dashboard. Trigger reconciliation immediately.
2. **Step 2: Check Signature & Authentication Failures:**
   - Did the webhook arrive but get rejected with `401 Unauthorized` or `400 Bad Request` due to a signature mismatch or payload parsing error?
   - Inspect application error logs and metric `webhook_signature_failures_total`.
3. **Step 3: Check Dead Letter Queues (DLQ) & Message Brokers:**
   - If webhooks are buffered via SQS/Kafka/RabbitMQ, check if the consumer crashed, timed out, or moved the message to the DLQ due to database locking.
4. **Step 4: Check Database State & Transaction Contention:**
   - Query `payments` table: Is there an entry for `order_id`?
   - *If payment row exists but trials is still PENDING:* Database transaction partially failed or committed payment insertion without updating trial status (atomicity violation).
5. **Immediate Mitigation:**
   - Run manual or automated reconciliation:
     `POST /api/reconcile` with `provider_status: SUCCESS`.
   - Restore customer subscription to `ACTIVE` and notify user.

---

### 2.5. Metrics and Alerts for this Flow

#### Metrics (Prometheus / Datadog):
1. `payment_webhook_requests_total{status, provider}` — Webhook ingress throughput and response codes.
2. `payment_webhook_processing_latency_seconds` — Histogram of webhook handler execution time (alert on p99 > 500ms).
3. `subscription_state_transitions_total{from_state, to_state}` — Counter of trial state changes (monitors normal flow).
4. `subscription_illegal_downgrade_attempts_total` — Counter tracking any webhook attempting to degrade an `ACTIVE` subscription.
5. `reconciliation_drift_recovered_total` — Number of drift cases recovered by reconciliation.
6. `stuck_pending_trials_count` — Gauge tracking trials in `PENDING` status for $> 15$ minutes.

#### Alerts (PagerDuty / Slack):
- 🚨 **P1 Critical:** Webhook 4xx/5xx error rate $> 1\%$ over a 5-minute window.
- 🚨 **P1 Critical:** Webhook signature verification failures $> 5$ in 5 minutes (indicates key rotation issue or spoofing attack).
- ⚠️ **P2 Warning:** Reconciliation recovers $> 50$ orders per run (signals widespread webhook delivery drop from gateway).
- ⚠️ **P2 Warning:** Stuck `PENDING` trials count $> 10$ older than 30 minutes.

---

### 2.6. What would you improve with one more day?

1. **Simulated WireMock / Mock Payment Gateway Service:**
   - Build a standalone mock provider container capable of configurable webhook delays, network dropped packets, duplicate bursts, and signature signing to run chaos experiments without manual intervention.
2. **Contract Testing with Pact:**
   - Implement consumer-driven contract testing between the mobile/web clients and the subscription service to guarantee payload compatibility.
3. **Distributed Tracing (OpenTelemetry):**
   - Inject `traceparent` and correlation IDs across `POST /api/trials` $\to$ provider webhook $\to$ reconciliation, enabling visual trace debugging in Jaeger/Datadog.
4. **Load & Stress Testing with Locust / k6:**
   - Benchmark concurrent webhook throughput (e.g., 1,000 req/sec) to identify SQLite lock bottlenecks and test migration to PostgreSQL with `SELECT ... FOR UPDATE` row locks.

---

### 2.7. AI Tools Used & Contribution

- **Google Gemini / Antigravity Assistant**: Used for analyzing the codebase, formulating the risk-based testing strategy, identifying edge-case concurrency races, structuring formal bug reports with root-cause fixes, and scaffolding the pytest suite and configuration.

---

## 3. Automated Test Suite Setup & Execution

### 3.1. Prerequisites
- Python 3.9+ (tested on Python 3.14)
- `pytest` and `requests`

### 3.2. Setup Instructions

```bash
# 1. Navigate to directory (root of the extracted zip or workspace)
cd <extracted-submission-directory>

# 2. Install dependencies
pip install -r requirements.txt
```

### 3.3. Running the Test Suite

#### Option A: One-line Runner (Recommended)
```bash
./run_tests.sh
```
This script handles starting the background test server, running the full suite with pytest, generating detailed summary reports (`test_report.txt`), and cleaning up.

#### Option B: Running with Pytest Directly
Ensure the server is running (`python3 server.py --reset`), then:

```bash
# Run all tests (displays clear failure assertions for surfaced bugs)
pytest -v

# Run only passing contract/happy-path tests
pytest -v -m "not bug"

# Run specific functional suites
pytest -v tests/test_webhooks.py
pytest -v tests/test_reconciliation.py
pytest -v tests/test_concurrency.py
pytest -v tests/test_trials.py
pytest -v tests/test_subscriptions.py
```

---

## 4. Test Suite Mapping & Coverage

| Test File | Test Case | Category | Specification Rule | Status vs Server |
| :--- | :--- | :--- | :--- | :--- |
| `test_trials.py` | `test_create_trial_happy_path_monthly` | Functional | Rule 3 | **PASS** |
| `test_trials.py` | `test_create_trial_happy_path_yearly` | Functional | Rule 3 | **PASS** |
| `test_trials.py` | `test_create_trial_rejects_missing_fields` | Negative | API Contract | **PASS** |
| `test_trials.py` | `test_create_trial_rejects_invalid_plan` | Negative | API Contract | **PASS** |
| `test_trials.py` | `test_create_trial_duplicate_live_prevention` | Reliability | Rule 1 | **SURFACES BUG-005** |
| `test_trials.py` | `test_create_trial_rejects_negative_or_zero_amount` | Boundary | Rule 2 | **SURFACES BUG-006** |
| `test_trials.py` | `test_create_trial_rejects_boolean_amount` | Negative | Rule 2 | **SURFACES BUG-006** |
| `test_webhooks.py` | `test_webhook_payment_success_activates_trial` | Functional | Rule 5 | **PASS** |
| `test_webhooks.py` | `test_webhook_payment_failed_marks_trial_failed` | Functional | Rule 4 | **PASS** |
| `test_webhooks.py` | `test_webhook_unknown_order_makes_no_state_change` | Negative | Rule 10 | **PASS** |
| `test_webhooks.py` | `test_webhook_invalid_status_rejected` | Negative | Rule 4 | **PASS** |
| `test_webhooks.py` | `test_webhook_missing_signature_rejected` | Security | Rule 9 | **SURFACES BUG-001** |
| `test_webhooks.py` | `test_webhook_invalid_signature_rejected` | Security | Rule 9 | **SURFACES BUG-001** |
| `test_webhooks.py` | `test_webhook_out_of_order_failed_never_downgrades` | Async/Order | Rule 6 | **SURFACES BUG-002** |
| `test_webhooks.py` | `test_webhook_idempotency_duplicate_success_callbacks` | Idempotency | Rules 7, 8 | **SURFACES BUG-004** |
| `test_reconciliation.py`| `test_reconcile_recovers_pending_to_active` | Functional | Rule 12 | **PASS** |
| `test_reconciliation.py`| `test_reconcile_unauthorized_missing_internal_key`| Security | Rule 11 | **PASS** |
| `test_reconciliation.py`| `test_reconcile_unknown_order_returns_404` | Negative | API Contract | **PASS** |
| `test_reconciliation.py`| `test_reconcile_idempotency_active_trial_not_downgraded`| Idempotency | Rule 13 | **PASS** |
| `test_reconciliation.py`| `test_reconcile_recovers_failed_to_active` | Recovery | Rule 12 | **SURFACES BUG-003** |
| `test_concurrency.py` | `test_concurrent_trial_creation_single_live_trial` | Concurrency | Rules 1, 14 | **SURFACES BUG-005** |
| `test_concurrency.py` | `test_concurrent_webhooks_race_condition` | Concurrency | Rules 7, 8 | **SURFACES BUG-004** |
| `test_subscriptions.py`| `test_get_subscription_reflects_active_state` | Functional | API Contract | **PASS** |
| `test_subscriptions.py`| `test_get_subscription_non_existent_user_returns_404`| Functional | API Contract | **PASS** |
| `test_subscriptions.py`| `test_get_subscription_not_masked_by_subsequent_pending`| Bug Check | API Contract | **SURFACES BUG-007** |
| `test_subscriptions.py`| `test_get_subscription_trailing_slash_resilience` | Bug Check | API Contract | **SURFACES BUG-007** |

---

## 5. Submission Checklist Verification

- [x] **Risk-based test strategy** (`TEST_STRATEGY.md`)
- [x] **Defect report with root-cause analysis** (`BUGS.md`)
- [x] **Engineering & release documentation** (`README_SUBMISSION.md`)
- [x] **Automated test suite (26 comprehensive test cases)** (`tests/`)
- [x] **At least one idempotency test included** (`tests/test_webhooks.py`)
- [x] **At least one out-of-order webhook test included** (`tests/test_webhooks.py`)
- [x] **At least one concurrency test included** (`tests/test_concurrency.py`)
- [x] **At least one reconciliation test included** (`tests/test_reconciliation.py`)
- [x] **Business state and database assertions** (SQLite connection + API assertions)
- [x] **Test isolation strategy** (Automated DB reset fixture before each test)
- [x] **One-line run command** (`./run_tests.sh`)
- [x] **Packaged ZIP archive** for direct submission
