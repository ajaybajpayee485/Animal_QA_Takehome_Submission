# Defect Report: Subscription Reliability Challenge

This document details all defects identified during quality engineering analysis and automated testing of the `AnimallQAChallenge/1.0` service (`server.py`). Defects are prioritized by business risk and production impact.

---

## Defect Summary Matrix

| Defect ID | Title | Priority | Severity | Violated Business Rule |
| :--- | :--- | :--- | :--- | :--- |
| **BUG-001** | Missing Webhook Signature Verification (`X-Signature` ignored) | **P0** | **Critical** | Rule 9 |
| **BUG-002** | Active Trial Downgraded by Delayed/Out-of-Order Webhooks | **P0** | **Critical** | Rule 6 |
| **BUG-003** | Reconciliation Fails to Recover `FAILED` Trial on Provider `SUCCESS` | **P0** | **High** | Rule 12 |
| **BUG-004** | Webhook Retries Create Duplicate Payment Records for Same `provider_txn_id` | **P1** | **High** | Rules 7, 8 |
| **BUG-005** | Repeated and Concurrent Requests Create Duplicate Live Trials for Same User/Plan | **P1** | **High** | Rules 1, 14 |
| **BUG-006** | Trial Creation Accepts Non-Positive (`<= 0`) and Boolean Amounts | **P1** | **Medium** | Rule 2 |
| **BUG-007** | `GET /api/subscriptions/{user_id}` Masks Active Subscription & Fails on Trailing Slash | **P2** | **Medium** | Rule 5, API Contract |
| **BUG-008** | Missing Concurrency Synchronization (`DB_LOCK` unused) & Missing Database Constraints | **P2** | **Medium** | Rules 8, 14, Data Integrity |

---

## Detailed Defect Reports

---

### BUG-001: Missing Webhook Signature Verification (`X-Signature` Ignored)
- **Priority:** P0 (Blocker)
- **Severity:** Critical (Security Vulnerability)
- **Violated Rule:** Rule 9 ("Payment webhooks must include `X-Signature: qa-secret`. Invalid or missing signatures must return `401` and make no state change.")
- **Preconditions:** Server running on `http://127.0.0.1:18080`. An order in `PENDING` status exists.

#### Reproduction Steps:
1. Create a trial:
   ```bash
   curl -s -X POST http://127.0.0.1:18080/api/trials \
     -H "Content-Type: application/json" \
     -d '{"user_id": "victim_user", "plan": "yearly", "amount": 99900}'
   # Returns order_id: "ord_12345"
   ```
2. Post payment webhook without `X-Signature` header, or with an invalid signature:
   ```bash
   curl -s -X POST http://127.0.0.1:18080/api/webhooks/payment \
     -H "Content-Type: application/json" \
     -H "X-Signature: fake-signature" \
     -d '{"order_id": "ord_12345", "provider_txn_id": "txn_fake", "status": "SUCCESS"}'
   ```
3. Inspect trial status:
   ```bash
   curl -s http://127.0.0.1:18080/api/subscriptions/victim_user
   ```

#### Expected Behavior:
- Server returns `HTTP 401 Unauthorized` with `{"error": "unauthorized"}`.
- Zero state change occurs in SQLite: trial remains `PENDING`, no payment record created.

#### Actual Behavior:
- Server returns `HTTP 200 OK` with `{"status": "processed"}`.
- Trial status transitions to `ACTIVE` and an illegitimate payment record is recorded in `payments`.

#### Evidence:
- **Code Inspection (`server.py` line 167):**
  ```python
  # NOTE: signature handling is intentionally minimal for the challenge.
  conn = get_conn()
  # self.headers.get('X-Signature') is NEVER checked!
  ```
- **Automated Test:** `tests/test_webhooks.py::test_webhook_missing_signature_rejected` and `test_webhook_invalid_signature_rejected`.

#### Business & User Impact:
Critical security exploit. Any external user or malicious script can forge payment success notifications, granting unauthorized active subscriptions to any user without payment.

---

### BUG-002: Active Trial Downgraded by Delayed/Out-of-Order Webhooks
- **Priority:** P0 (Blocker)
- **Severity:** Critical
- **Violated Rule:** Rule 6 ("Once a trial is `ACTIVE`, a later duplicate/out-of-order `PENDING` or `FAILED` event must never downgrade it.")
- **Preconditions:** A trial is created and transitioned to `ACTIVE` via a `SUCCESS` webhook.

#### Reproduction Steps:
1. Create a trial for `user_alice`:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "user_alice", "plan": "monthly", "amount": 29900}'
   # Received order_id "ord_alice"
   ```
2. Send `SUCCESS` webhook:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/webhooks/payment -H "Content-Type: application/json" \
     -d '{"order_id": "ord_alice", "provider_txn_id": "txn_001", "status": "SUCCESS"}'
   # Status becomes ACTIVE
   ```
3. Send a delayed/out-of-order `FAILED` webhook (e.g., from an initial failed retry that arrived late):
   ```bash
   curl -X POST http://127.0.0.1:18080/api/webhooks/payment -H "Content-Type: application/json" \
     -d '{"order_id": "ord_alice", "provider_txn_id": "txn_000", "status": "FAILED"}'
   ```
4. Query subscription:
   ```bash
   curl http://127.0.0.1:18080/api/subscriptions/user_alice
   ```

#### Expected Behavior:
- Once `ACTIVE`, status is monotonic and cannot be degraded to `FAILED` or `PENDING` by late webhooks.
- `trials.status` remains `ACTIVE`.

#### Actual Behavior:
- Server blindly executes:
  ```python
  UPDATE trials SET status=?, updated_at=? WHERE order_id=?
  ```
- `trials.status` is overwritten to `FAILED`.

#### Evidence:
- **API Response:** `GET /api/subscriptions/user_alice` returns `"status": "FAILED"`.
- **Database Row:** `trials` table shows status downgraded from `ACTIVE` to `FAILED`.
- **Automated Test:** `tests/test_webhooks.py::test_webhook_out_of_order_failed_after_success_never_downgrades`.

#### Business & User Impact:
Paying customers who successfully completed payment abruptly lose access to paid features when out-of-order gateway callbacks arrive. Causes customer churn, brand damage, and high customer support burden.

---

### BUG-003: Reconciliation Fails to Recover `FAILED` Trial on Provider `SUCCESS`
- **Priority:** P0 / High
- **Severity:** High
- **Violated Rule:** Rule 12 ("If the provider reports `SUCCESS`, reconciliation must be able to recover an application record that is incorrectly `PENDING` or `FAILED`.")
- **Preconditions:** A trial record has status `FAILED` in the database.

#### Reproduction Steps:
1. Trial exists with `order_id = "ord_recover"` and `status = 'FAILED'`.
2. Provider confirms settlement succeeded. Run reconciliation:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/reconcile \
     -H "Content-Type: application/json" \
     -H "X-Internal-Key: qa-internal" \
     -d '{"order_id": "ord_recover", "provider_txn_id": "txn_rec_99", "provider_status": "SUCCESS"}'
   ```
3. Check `trials` status in database:
   ```bash
   curl http://127.0.0.1:18080/api/debug/trials?user_id=...
   ```

#### Expected Behavior:
- Reconciliation updates `trials.status` to `ACTIVE` and inserts payment record into `payments`.

#### Actual Behavior:
- Endpoint returns `HTTP 200 {"status": "reconciled"}`.
- However, SQLite row is unchanged: `trials.status` remains `FAILED`!
- Root cause in `server.py` line 203-204:
  ```python
  # Intentionally only reconciles PENDING records.
  if row['status'] == 'PENDING':
      ...
  ```
  The logic ignores `FAILED` rows completely!

#### Evidence:
- **Database State:** `SELECT status FROM trials WHERE order_id='ord_recover'` still returns `FAILED`.
- **Automated Test:** `tests/test_reconciliation.py::test_reconcile_recovers_failed_to_active`.

#### Business & User Impact:
The reconciliation process is unable to self-heal falsely failed payments. When payments succeed at the gateway after an initial failure or timeout, the automated reconciler fails to restore service, leading to permanent service denial for paying customers.

---

### BUG-004: Webhook Retries Create Duplicate Payment Records for Same `provider_txn_id`
- **Priority:** P1
- **Severity:** High
- **Violated Rules:**
  - Rule 7: "Provider callbacks are at-least-once. Processing the same payment event repeatedly must be idempotent."
  - Rule 8: "A `provider_txn_id` must represent one payment only and must not create duplicate payment records when retried."
- **Preconditions:** A trial exists.

#### Reproduction Steps:
1. Send initial webhook:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/webhooks/payment -H "Content-Type: application/json" \
     -d '{"order_id": "ord_idem", "provider_txn_id": "txn_unique_1", "status": "SUCCESS"}'
   ```
2. Gateway retries the exact same webhook (same `provider_txn_id`):
   ```bash
   curl -X POST http://127.0.0.1:18080/api/webhooks/payment -H "Content-Type: application/json" \
     -d '{"order_id": "ord_idem", "provider_txn_id": "txn_unique_1", "status": "SUCCESS"}'
   ```
3. Inspect `payments` table:
   ```bash
   curl http://127.0.0.1:18080/api/debug/payments?order_id=ord_idem
   ```

#### Expected Behavior:
- Webhook processing is idempotent. Second call is acknowledged (`200 OK`) but does not create an additional record.
- Exactly 1 record in `payments` with `provider_txn_id = 'txn_unique_1'`.

#### Actual Behavior:
- Server blindly executes `INSERT INTO payments(...)` on every call.
- 2 distinct records exist in `payments` table with the identical `provider_txn_id`.

#### Evidence:
- **Debug Payments Output:**
  ```json
  {
    "payments": [
      {"id": 1, "order_id": "ord_idem", "provider_txn_id": "txn_unique_1", "provider_status": "SUCCESS"},
      {"id": 2, "order_id": "ord_idem", "provider_txn_id": "txn_unique_1", "provider_status": "SUCCESS"}
    ]
  }
  ```
- **Automated Test:** `tests/test_webhooks.py::test_webhook_idempotency_duplicate_success_callbacks`.

#### Business & User Impact:
At-least-once delivery is standard for all payment providers (Stripe, Razorpay, Cashfree). Duplicate payment records corrupt financial ledgers, double-count gross merchandise value (GMV), and risk automated double-refund triggers.

---

### BUG-005: Repeated & Concurrent Requests Create Duplicate Live Trials for Same User/Plan
- **Priority:** P1
- **Severity:** High
- **Violated Rules:**
  - Rule 1: "A user can have only one live trial for the same plan. Repeated client requests must not create duplicate live trials."
  - Rule 14: "Concurrent requests for the same user/plan must still respect the single-live-trial rule."
- **Preconditions:** Server running.

#### Reproduction Steps:
1. Send first request:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "user_multi", "plan": "yearly", "amount": 100}'
   ```
2. Send second request with identical `user_id` and `plan`:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "user_multi", "plan": "yearly", "amount": 100}'
   ```
3. Or fire 5 concurrent requests using a thread pool.

#### Expected Behavior:
- Only 1 live trial created. Second request either returns the existing live trial safely with `HTTP 200` or rejects with `HTTP 409 Conflict`.
- Total live trials for `(user_multi, yearly)` in SQLite is 1.

#### Actual Behavior:
- Server blindly executes `INSERT INTO trials` on every request without querying existing active/pending trials.
- Returns `HTTP 201 Created` with a new `order_id` every time.
- Under concurrency, 5 parallel requests create 5 live trials.

#### Evidence:
- **Database Inspection:** `SELECT count(*) FROM trials WHERE user_id='user_multi' AND plan='yearly'` returns 5.
- **Automated Tests:**
  - `tests/test_trials.py::test_create_trial_duplicate_live_prevention`
  - `tests/test_concurrency.py::test_concurrent_trial_creation_single_live_trial`

#### Business & User Impact:
Users double-clicking the checkout button create multiple orders, resulting in accidental double subscriptions, multiple payment charges, and fractured subscription history.

---

### BUG-006: Trial Creation Accepts Non-Positive (`<= 0`) and Boolean Amounts
- **Priority:** P1 / P2
- **Severity:** Medium
- **Violated Rule:** Rule 2 ("Trial amount must be a positive integer in paise.")
- **Preconditions:** Server running.

#### Reproduction Steps:
1. Send trial creation with negative amount:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "u_neg", "plan": "monthly", "amount": -100}'
   ```
2. Send trial creation with zero amount:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "u_zero", "plan": "monthly", "amount": 0}'
   ```
3. Send trial creation with boolean amount:
   ```bash
   curl -X POST http://127.0.0.1:18080/api/trials -H "Content-Type: application/json" \
     -d '{"user_id": "u_bool", "plan": "monthly", "amount": true}'
   ```

#### Expected Behavior:
- Server validates that `amount` is an integer strictly greater than 0 (`amount > 0 and type(amount) is int`).
- Returns `HTTP 400 Bad Request` with `{"error": "invalid_request"}`.

#### Actual Behavior:
- Server checks `not isinstance(amount, int)`.
  - In Python, negative numbers and `0` are instances of `int`.
  - In Python, `isinstance(True, int)` evaluates to `True` (bool is a subclass of int).
- Returns `HTTP 201 Created`. Trials are saved in DB with amounts `-100`, `0`, and `1`.

#### Evidence:
- **API Response:** `HTTP 201` with `{"status": "PENDING", "order_id": "..."}`.
- **Automated Test:** `tests/test_trials.py::test_create_trial_rejects_negative_or_zero_amount` and `test_create_trial_rejects_boolean_amount`.

#### Business & User Impact:
Users can initiate negative or zero-value transactions, corrupting financial reporting and risking zero-amount trial bypass vulnerabilities.

---

### BUG-007: `GET /api/subscriptions/{user_id}` Masks Active Subscription & Fails on Trailing Slash
- **Priority:** P2
- **Severity:** Medium
- **Violated Rule:** Rule 5 & API Contract
- **Preconditions:** User has an active subscription, followed by a subsequent pending trial attempt.

#### Reproduction Steps:
1. Create and activate trial 1 (`ord_1`, status `ACTIVE`).
2. Later, an orphaned or abandoned trial 2 (`ord_2`, status `PENDING`) is created for the same user.
3. Call `GET /api/subscriptions/{user_id}`.
4. Call `GET /api/subscriptions/{user_id}/` (with trailing slash).

#### Expected Behavior:
1. `GET /api/subscriptions/{user_id}` returns the user's current live/active subscription.
2. Trailing slashes should be normalized and return `HTTP 200` with the subscription.

#### Actual Behavior:
1. Query executes:
   ```sql
   SELECT * FROM trials WHERE user_id=? ORDER BY created_at DESC LIMIT 1
   ```
   This returns `ord_2` (`PENDING`), completely hiding `ord_1` (`ACTIVE`). The client thinks the user has no active subscription!
2. Path parsing uses `path.split('/')[-1]`. For `/api/subscriptions/user_123/`, this evaluates to `""`, returning `HTTP 404 {"error": "not_found"}`.

#### Evidence:
- **API Response:** `HTTP 200` returns `PENDING` instead of `ACTIVE`.
- **API Response with slash:** `HTTP 404`.
- **Automated Test:** `tests/test_subscriptions.py::test_get_subscription_not_masked_by_subsequent_pending`.

#### Business & User Impact:
Users who paid and are active are locked out because the latest abandoned cart/trial masks their valid active subscription. Mobile apps appending trailing slashes crash or show 404 errors.

---

### BUG-008: Missing Concurrency Synchronization (`DB_LOCK` Unused) & Missing DB Constraints
- **Priority:** P2
- **Severity:** Medium
- **Violated Rules:** Rules 8, 14 & Data Integrity
- **Preconditions:** Multi-threaded request execution.

#### Findings & Actual Behavior:
1. `DB_LOCK = threading.Lock()` is instantiated at line 15 of `server.py`, but is **never acquired or referenced** anywhere in the code.
2. The SQLite schema (`init_db`) lacks foundational relational integrity constraints:
   - `trials.order_id` lacks `UNIQUE` constraint.
   - `trials` lacks composite unique constraint or filtered index on `(user_id, plan)` for active trials.
   - `trials.amount` lacks `CHECK (amount > 0)` constraint.
   - `payments.provider_txn_id` lacks `UNIQUE` constraint.
   - `payments.order_id` lacks `FOREIGN KEY (order_id) REFERENCES trials(order_id)`.

#### Remediation Suggestion:
1. Implement transaction isolation and synchronization with `DB_LOCK` or write-ahead logging (`WAL` mode) with atomic transactions (`BEGIN IMMEDIATE`).
2. Add relational constraints and indexes to `init_db()` to enforce data invariants at the storage layer.
