import os
import sqlite3
import subprocess
import time
import pytest
import requests

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 18080
BASE_URL = f"http://{SERVER_HOST}:{SERVER_PORT}"
DB_PATH = os.path.join(os.path.dirname(__file__), "qa_challenge.db")
WEBHOOK_SECRET = "qa-secret"
INTERNAL_KEY = "qa-internal"


class APIClient:
    """Wrapper around API requests for concise, expressive test assertions."""

    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()

    def health(self):
        return self.session.get(f"{self.base_url}/health", timeout=5)

    def reset_db(self, internal_key: str = INTERNAL_KEY):
        headers = {}
        if internal_key is not None:
            headers["X-Internal-Key"] = internal_key
        return self.session.post(f"{self.base_url}/api/admin/reset", headers=headers, timeout=5)

    def create_trial(self, user_id, plan, amount):
        payload = {}
        if user_id is not None:
            payload["user_id"] = user_id
        if plan is not None:
            payload["plan"] = plan
        if amount is not None:
            payload["amount"] = amount
        return self.session.post(f"{self.base_url}/api/trials", json=payload, timeout=5)

    def send_webhook(self, order_id, provider_txn_id, status, signature: str = WEBHOOK_SECRET):
        headers = {}
        if signature is not None:
            headers["X-Signature"] = signature
        payload = {}
        if order_id is not None:
            payload["order_id"] = order_id
        if provider_txn_id is not None:
            payload["provider_txn_id"] = provider_txn_id
        if status is not None:
            payload["status"] = status
        return self.session.post(
            f"{self.base_url}/api/webhooks/payment", json=payload, headers=headers, timeout=5
        )

    def reconcile(
        self, order_id, provider_txn_id, provider_status, internal_key: str = INTERNAL_KEY
    ):
        headers = {}
        if internal_key is not None:
            headers["X-Internal-Key"] = internal_key
        payload = {}
        if order_id is not None:
            payload["order_id"] = order_id
        if provider_txn_id is not None:
            payload["provider_txn_id"] = provider_txn_id
        if provider_status is not None:
            payload["provider_status"] = provider_status
        return self.session.post(
            f"{self.base_url}/api/reconcile", json=payload, headers=headers, timeout=5
        )

    def get_subscription(self, user_id: str, trailing_slash: bool = False):
        slash = "/" if trailing_slash else ""
        return self.session.get(f"{self.base_url}/api/subscriptions/{user_id}{slash}", timeout=5)

    def get_debug_trials(self, user_id: str = None):
        params = {"user_id": user_id} if user_id else {}
        return self.session.get(f"{self.base_url}/api/debug/trials", params=params, timeout=5)

    def get_debug_payments(self, order_id: str = None):
        params = {"order_id": order_id} if order_id else {}
        return self.session.get(f"{self.base_url}/api/debug/payments", params=params, timeout=5)


@pytest.fixture(scope="session")
def base_url():
    return BASE_URL


@pytest.fixture(scope="session", autouse=True)
def ensure_server_running(base_url):
    """Ensure the challenge server is running before executing any tests.

    If not running, launch server.py as a subprocess and terminate after the session.
    """
    server_process = None
    try:
        r = requests.get(f"{base_url}/health", timeout=1)
        if r.status_code == 200:
            yield
            return
    except requests.RequestException:
        pass

    # Server not running: start it
    server_path = os.path.join(os.path.dirname(__file__), "server.py")
    server_process = subprocess.Popen(
        ["python3", server_path, "--reset"],
        cwd=os.path.dirname(__file__),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait for server to be responsive
    deadline = time.time() + 5
    started = False
    while time.time() < deadline:
        try:
            r = requests.get(f"{base_url}/health", timeout=1)
            if r.status_code == 200:
                started = True
                break
        except requests.RequestException:
            time.sleep(0.1)

    if not started:
        if server_process:
            server_process.terminate()
        raise RuntimeError("Failed to start server.py for automated tests")

    yield

    if server_process:
        server_process.terminate()
        server_process.wait()


@pytest.fixture
def client(base_url):
    return APIClient(base_url)


@pytest.fixture(autouse=True)
def isolate_test_db(client):
    """Reset the database before every test to guarantee test isolation."""
    res = client.reset_db(internal_key=INTERNAL_KEY)
    assert res.status_code == 200, f"Failed to reset DB: {res.text}"


@pytest.fixture
def db_conn():
    """Provides direct connection to SQLite database for deep state invariant assertions."""
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()
