import pytest


@pytest.mark.p0
@pytest.mark.reconciliation
def test_reconcile_recovers_pending_to_active(client, db_conn):
    """Rule 12: If provider reports SUCCESS, reconciliation recovers a PENDING record to ACTIVE."""
    res_trial = client.create_trial(user_id="rec_user_1", plan="yearly", amount=99900)
    order_id = res_trial.json()["order_id"]

    res_rec = client.reconcile(
        order_id=order_id,
        provider_txn_id="txn_rec_001",
        provider_status="SUCCESS",
        internal_key="qa-internal",
    )
    assert res_rec.status_code == 200
    assert res_rec.json().get("status") == "reconciled"

    # Verify trial transitioned to ACTIVE
    row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert row["status"] == "ACTIVE"

    # Verify payment recorded
    pay_row = db_conn.execute("SELECT * FROM payments WHERE order_id=?", (order_id,)).fetchone()
    assert pay_row is not None
    assert pay_row["provider_txn_id"] == "txn_rec_001"


@pytest.mark.p0
@pytest.mark.reconciliation
@pytest.mark.bug
def test_reconcile_recovers_failed_to_active(client, db_conn):
    """Rule 12: If the provider reports SUCCESS, reconciliation must be able to recover

    an application record that is incorrectly PENDING or FAILED.
    Surfaces BUG-003.
    """
    res_trial = client.create_trial(user_id="rec_user_2", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]

    # Webhook prematurely marked trial as FAILED
    client.send_webhook(order_id=order_id, provider_txn_id="txn_fail", status="FAILED")
    row_before = db_conn.execute("SELECT status FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert row_before["status"] == "FAILED"

    # Reconciliation runs with provider_status = SUCCESS
    res_rec = client.reconcile(
        order_id=order_id,
        provider_txn_id="txn_settled_succ",
        provider_status="SUCCESS",
        internal_key="qa-internal",
    )
    assert res_rec.status_code == 200

    # Invariant: Reconciliation must recover the FAILED record to ACTIVE!
    row_after = db_conn.execute("SELECT status FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert row_after["status"] == "ACTIVE", (
        f"[Rule 12 Violation] Reconciliation failed to recover FAILED trial to ACTIVE when provider reported SUCCESS! "
        f"Trial remained in '{row_after['status']}' state. (See BUGS.md - BUG-003)"
    )


@pytest.mark.p1
@pytest.mark.reconciliation
def test_reconcile_unauthorized_missing_internal_key(client):
    """Rule 11: Reconciliation is an internal API. It requires X-Internal-Key: qa-internal."""
    res_trial = client.create_trial(user_id="rec_user_3", plan="monthly", amount=100)
    order_id = res_trial.json()["order_id"]

    # Omitted key
    res1 = client.reconcile(
        order_id=order_id,
        provider_txn_id="txn_1",
        provider_status="SUCCESS",
        internal_key=None,
    )
    assert res1.status_code == 401
    assert res1.json().get("error") == "unauthorized"

    # Invalid key
    res2 = client.reconcile(
        order_id=order_id,
        provider_txn_id="txn_1",
        provider_status="SUCCESS",
        internal_key="wrong-key",
    )
    assert res2.status_code == 401


@pytest.mark.p1
@pytest.mark.reconciliation
def test_reconcile_unknown_order_returns_404(client):
    """Reconciliation of non-existent order must return 404 order_not_found."""
    res = client.reconcile(
        order_id="ord_non_existent_123",
        provider_txn_id="txn_1",
        provider_status="SUCCESS",
        internal_key="qa-internal",
    )
    assert res.status_code == 404
    assert res.json().get("error") == "order_not_found"


@pytest.mark.p1
@pytest.mark.reconciliation
@pytest.mark.idempotency
def test_reconcile_idempotency_active_trial_not_downgraded(client, db_conn):
    """Rule 13: Reconciliation must also be idempotent and must never downgrade an already ACTIVE trial."""
    res_trial = client.create_trial(user_id="rec_user_4", plan="yearly", amount=99900)
    order_id = res_trial.json()["order_id"]

    # Webhook activates trial
    client.send_webhook(order_id=order_id, provider_txn_id="txn_active", status="SUCCESS")

    # Reconciliation runs with provider_status FAILED
    res_rec = client.reconcile(
        order_id=order_id,
        provider_txn_id="txn_fail_late",
        provider_status="FAILED",
        internal_key="qa-internal",
    )
    assert res_rec.status_code == 200

    # Invariant: Must remain ACTIVE
    row = db_conn.execute("SELECT status FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert row["status"] == "ACTIVE"
