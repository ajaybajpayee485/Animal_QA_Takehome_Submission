import pytest


@pytest.mark.p0
@pytest.mark.trials
def test_create_trial_happy_path_monthly(client, db_conn):
    """Rule 3: New trials start in PENDING state with positive amount and plan."""
    res = client.create_trial(user_id="user_m1", plan="monthly", amount=29900)
    assert res.status_code == 201, f"Expected 201 Created, got {res.status_code}: {res.text}"

    data = res.json()
    assert "order_id" in data
    assert data["order_id"].startswith("ord_")
    assert data["status"] == "PENDING"

    # Direct database verification
    row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (data["order_id"],)).fetchone()
    assert row is not None, "Trial was not persisted to SQLite database"
    assert row["user_id"] == "user_m1"
    assert row["plan"] == "monthly"
    assert row["amount"] == 29900
    assert row["status"] == "PENDING"
    assert row["created_at"] > 0
    assert row["updated_at"] >= row["created_at"]


@pytest.mark.p0
@pytest.mark.trials
def test_create_trial_happy_path_yearly(client, db_conn):
    """Rule 3: New yearly trials start in PENDING state."""
    res = client.create_trial(user_id="user_y1", plan="yearly", amount=99900)
    assert res.status_code == 201
    data = res.json()
    assert data["status"] == "PENDING"

    row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (data["order_id"],)).fetchone()
    assert row is not None
    assert row["plan"] == "yearly"
    assert row["amount"] == 99900


@pytest.mark.p1
@pytest.mark.trials
def test_create_trial_rejects_missing_fields(client):
    """Negative: Missing required fields must return 400 Bad Request."""
    res1 = client.create_trial(user_id="", plan="monthly", amount=100)
    assert res1.status_code == 400
    assert res1.json().get("error") == "invalid_request"

    res2 = client.create_trial(user_id="u2", plan="", amount=100)
    assert res2.status_code == 400

    res3 = client.create_trial(user_id="u3", plan="monthly", amount=None)
    assert res3.status_code == 400


@pytest.mark.p1
@pytest.mark.trials
def test_create_trial_rejects_invalid_plan(client):
    """Negative: Unsupported plan tiers must return 400 Bad Request."""
    res = client.create_trial(user_id="u1", plan="lifetime", amount=50000)
    assert res.status_code == 400
    assert res.json().get("error") == "invalid_request"


@pytest.mark.p0
@pytest.mark.trials
@pytest.mark.bug
def test_create_trial_duplicate_live_prevention(client, db_conn):
    """Rule 1: A user can have only one live trial for the same plan.

    Repeated client requests must not create duplicate live trials.
    Surfaces BUG-005.
    """
    res1 = client.create_trial(user_id="user_dup", plan="yearly", amount=1000)
    assert res1.status_code == 201
    order_id_1 = res1.json()["order_id"]

    # Second creation attempt for same user and plan
    res2 = client.create_trial(user_id="user_dup", plan="yearly", amount=1000)

    # Invariants:
    # 1. Database must contain exactly 1 trial record for this user and plan
    rows = db_conn.execute(
        "SELECT * FROM trials WHERE user_id=? AND plan=?", ("user_dup", "yearly")
    ).fetchall()
    assert len(rows) == 1, (
        f"[Rule 1 Violation] Repeated client request created duplicate live trials! "
        f"Expected 1 trial in database, found {len(rows)}. (See BUGS.md - BUG-005)"
    )

    # 2. If 200/201 returned on retry, it must return the existing live order
    if res2.status_code in (200, 201):
        assert res2.json().get("order_id") == order_id_1, (
            "Safe retry returned a different order_id instead of referencing the existing live trial."
        )


@pytest.mark.p1
@pytest.mark.trials
@pytest.mark.bug
def test_create_trial_rejects_negative_or_zero_amount(client, db_conn):
    """Rule 2: Trial amount must be a positive integer in paise.

    Surfaces BUG-006.
    """
    res_zero = client.create_trial(user_id="u_zero", plan="monthly", amount=0)
    assert res_zero.status_code == 400, (
        f"[Rule 2 Violation] Trial accepted amount=0 with status {res_zero.status_code}! "
        f"Expected 400 Bad Request. (See BUGS.md - BUG-006)"
    )

    res_neg = client.create_trial(user_id="u_neg", plan="monthly", amount=-100)
    assert res_neg.status_code == 400, (
        f"[Rule 2 Violation] Trial accepted negative amount=-100 with status {res_neg.status_code}! "
        f"Expected 400 Bad Request. (See BUGS.md - BUG-006)"
    )

    # Verify no records inserted
    count = db_conn.execute("SELECT count(*) FROM trials WHERE amount <= 0").fetchone()[0]
    assert count == 0, f"Found {count} trials with non-positive amount in database"


@pytest.mark.p1
@pytest.mark.trials
@pytest.mark.bug
def test_create_trial_rejects_boolean_amount(client, db_conn):
    """Rule 2: Boolean amount (e.g., True) must not be accepted as integer 1.

    Surfaces BUG-006.
    """
    res = client.create_trial(user_id="u_bool", plan="monthly", amount=True)
    assert res.status_code == 400, (
        f"[Rule 2 Violation] Trial accepted boolean True as amount with status {res.status_code}! "
        f"Expected 400 Bad Request. (See BUGS.md - BUG-006)"
    )
