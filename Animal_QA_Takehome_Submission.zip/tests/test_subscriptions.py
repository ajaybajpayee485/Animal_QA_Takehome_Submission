import pytest


@pytest.mark.p1
@pytest.mark.subscriptions
def test_get_subscription_reflects_active_state(client):
    """GET /api/subscriptions/{user_id} correctly returns the active trial."""
    res_trial = client.create_trial(user_id="sub_user_1", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]

    client.send_webhook(order_id=order_id, provider_txn_id="txn_sub_1", status="SUCCESS")

    res_sub = client.get_subscription("sub_user_1")
    assert res_sub.status_code == 200
    data = res_sub.json()
    assert data["user_id"] == "sub_user_1"
    assert data["order_id"] == order_id
    assert data["status"] == "ACTIVE"
    assert data["plan"] == "monthly"
    assert data["amount"] == 29900


@pytest.mark.p2
@pytest.mark.subscriptions
def test_get_subscription_non_existent_user_returns_404(client):
    """Querying a non-existent user returns 404 Not Found."""
    res = client.get_subscription("user_non_existent_999")
    assert res.status_code == 404
    assert res.json().get("error") == "not_found"


@pytest.mark.p1
@pytest.mark.subscriptions
@pytest.mark.bug
def test_get_subscription_not_masked_by_subsequent_pending(client):
    """Active subscription must not be masked by a subsequent pending trial record.

    Surfaces BUG-007.
    """
    # 1. User purchases monthly plan and it activates
    res1 = client.create_trial(user_id="sub_user_2", plan="monthly", amount=29900)
    order1 = res1.json()["order_id"]
    client.send_webhook(order_id=order1, provider_txn_id="tx_active", status="SUCCESS")

    # 2. User later attempts another checkout which is abandoned in PENDING
    res2 = client.create_trial(user_id="sub_user_2", plan="yearly", amount=99900)
    order2 = res2.json()["order_id"]

    # 3. Reading subscriptions should return the ACTIVE subscription, not the abandoned PENDING one
    res_sub = client.get_subscription("sub_user_2")
    assert res_sub.status_code == 200
    data = res_sub.json()
    assert data["status"] == "ACTIVE", (
        f"[API Contract Violation] GET /api/subscriptions/{data['user_id']} returned status '{data['status']}' "
        f"instead of 'ACTIVE'! The active subscription is masked by a subsequent pending record. "
        f"(See BUGS.md - BUG-007)"
    )


@pytest.mark.p2
@pytest.mark.subscriptions
@pytest.mark.bug
def test_get_subscription_trailing_slash_resilience(client):
    """GET /api/subscriptions/{user_id}/ with trailing slash should not crash with 404 not_found.

    Surfaces BUG-007.
    """
    client.create_trial(user_id="sub_user_slash", plan="monthly", amount=100)

    res = client.get_subscription("sub_user_slash", trailing_slash=True)
    assert res.status_code == 200, (
        f"[API Contract Violation] Trailing slash caused 404 Not Found due to naive path.split('/')[-1] parsing. "
        f"(See BUGS.md - BUG-007)"
    )
