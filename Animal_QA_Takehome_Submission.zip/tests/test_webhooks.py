import pytest


@pytest.mark.p0
@pytest.mark.webhooks
def test_webhook_payment_success_activates_trial(client, db_conn):
    """Rule 5: A successful payment activates the trial: application status becomes ACTIVE."""
    res_trial = client.create_trial(user_id="alice", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]

    res_wh = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_succ_01",
        status="SUCCESS",
        signature="qa-secret",
    )
    assert res_wh.status_code == 200
    assert res_wh.json().get("status") == "processed"

    # Business state assertion via API
    sub = client.get_subscription("alice").json()
    assert sub["status"] == "ACTIVE", f"Expected ACTIVE status, got {sub['status']}"

    # Database state assertion
    trial_row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_row["status"] == "ACTIVE"

    # Assert exactly 1 payment record logged
    pay_rows = db_conn.execute("SELECT * FROM payments WHERE order_id=?", (order_id,)).fetchall()
    assert len(pay_rows) == 1
    assert pay_rows[0]["provider_txn_id"] == "txn_succ_01"
    assert pay_rows[0]["provider_status"] == "SUCCESS"


@pytest.mark.p0
@pytest.mark.webhooks
def test_webhook_payment_failed_marks_trial_failed(client, db_conn):
    """Rule 4: Payment provider FAILED status transitions pending trial to FAILED."""
    res_trial = client.create_trial(user_id="bob", plan="yearly", amount=99900)
    order_id = res_trial.json()["order_id"]

    res_wh = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_fail_01",
        status="FAILED",
        signature="qa-secret",
    )
    assert res_wh.status_code == 200

    trial_row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_row["status"] == "FAILED"


@pytest.mark.p0
@pytest.mark.webhooks
@pytest.mark.bug
def test_webhook_missing_signature_rejected(client, db_conn):
    """Rule 9: Payment webhooks must include X-Signature: qa-secret.

    Missing signature must return 401 and make no state change.
    Surfaces BUG-001.
    """
    res_trial = client.create_trial(user_id="charlie", plan="monthly", amount=100)
    order_id = res_trial.json()["order_id"]

    # Send webhook with signature=None (header omitted)
    res_wh = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_no_sig",
        status="SUCCESS",
        signature=None,
    )
    assert res_wh.status_code == 401, (
        f"[Rule 9 Violation] Webhook without X-Signature was accepted with status {res_wh.status_code}! "
        f"Expected 401 Unauthorized. (See BUGS.md - BUG-001)"
    )

    # Invariant: State must remain unchanged (PENDING)
    trial_row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_row["status"] == "PENDING", "Trial was modified by unauthorized webhook"

    # Invariant: Zero payment records
    pay_count = db_conn.execute(
        "SELECT count(*) FROM payments WHERE order_id=?", (order_id,)
    ).fetchone()[0]
    assert pay_count == 0, "Payment record created by unauthorized webhook"


@pytest.mark.p0
@pytest.mark.webhooks
@pytest.mark.bug
def test_webhook_invalid_signature_rejected(client, db_conn):
    """Rule 9: Invalid signature must return 401 and make no state change.

    Surfaces BUG-001.
    """
    res_trial = client.create_trial(user_id="david", plan="monthly", amount=100)
    order_id = res_trial.json()["order_id"]

    res_wh = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_bad_sig",
        status="SUCCESS",
        signature="invalid-secret-key",
    )
    assert res_wh.status_code == 401, (
        f"[Rule 9 Violation] Webhook with invalid X-Signature was accepted with status {res_wh.status_code}! "
        f"Expected 401 Unauthorized. (See BUGS.md - BUG-001)"
    )


@pytest.mark.p0
@pytest.mark.webhooks
@pytest.mark.bug
def test_webhook_out_of_order_failed_never_downgrades(client, db_conn):
    """Rule 6: Once a trial is ACTIVE, a later duplicate/out-of-order FAILED event must never downgrade it.

    Surfaces BUG-002.
    """
    res_trial = client.create_trial(user_id="eve", plan="yearly", amount=99900)
    order_id = res_trial.json()["order_id"]

    # 1. SUCCESS webhook arrives first -> trial becomes ACTIVE
    res_success = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_order_1",
        status="SUCCESS",
        signature="qa-secret",
    )
    assert res_success.status_code == 200

    trial_row = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_row["status"] == "ACTIVE"

    # 2. Delayed/Out-of-order FAILED webhook arrives
    res_failed = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_order_0_delayed",
        status="FAILED",
        signature="qa-secret",
    )
    assert res_failed.status_code in (200, 409)

    # 3. Invariant: Trial status MUST remain ACTIVE!
    trial_after = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_after["status"] == "ACTIVE", (
        f"[Rule 6 Violation] Active trial was downgraded to '{trial_after['status']}' by out-of-order FAILED event! "
        f"Expected 'ACTIVE'. (See BUGS.md - BUG-002)"
    )


@pytest.mark.p0
@pytest.mark.webhooks
@pytest.mark.bug
def test_webhook_out_of_order_pending_never_downgrades(client, db_conn):
    """Rule 6: Once a trial is ACTIVE, a later duplicate/out-of-order PENDING event must never downgrade it.

    Surfaces BUG-002.
    """
    res_trial = client.create_trial(user_id="frank", plan="yearly", amount=99900)
    order_id = res_trial.json()["order_id"]

    client.send_webhook(order_id=order_id, provider_txn_id="tx_1", status="SUCCESS")

    # Delayed PENDING event
    client.send_webhook(order_id=order_id, provider_txn_id="tx_0", status="PENDING")

    trial_after = db_conn.execute("SELECT * FROM trials WHERE order_id=?", (order_id,)).fetchone()
    assert trial_after["status"] == "ACTIVE", (
        f"[Rule 6 Violation] Active trial was downgraded to '{trial_after['status']}' by out-of-order PENDING event! "
        f"(See BUGS.md - BUG-002)"
    )


@pytest.mark.p0
@pytest.mark.webhooks
@pytest.mark.idempotency
@pytest.mark.bug
def test_webhook_idempotency_duplicate_success_callbacks(client, db_conn):
    """Rules 7 & 8: Processing the same payment event repeatedly must be idempotent.

    A provider_txn_id must represent one payment only and must not create duplicate payment records.
    Surfaces BUG-004.
    """
    res_trial = client.create_trial(user_id="grace", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]
    txn_id = "txn_idempotent_999"

    # Send first webhook callback
    res1 = client.send_webhook(order_id=order_id, provider_txn_id=txn_id, status="SUCCESS")
    assert res1.status_code == 200

    # Send second duplicate webhook callback with identical provider_txn_id
    res2 = client.send_webhook(order_id=order_id, provider_txn_id=txn_id, status="SUCCESS")
    assert res2.status_code == 200

    # Invariant: Exactly 1 record in payments table for txn_id
    rows = db_conn.execute("SELECT * FROM payments WHERE provider_txn_id=?", (txn_id,)).fetchall()
    assert len(rows) == 1, (
        f"[Rule 8 Violation] Duplicate payment records created for identical provider_txn_id '{txn_id}'! "
        f"Expected 1 record, found {len(rows)}. (See BUGS.md - BUG-004)"
    )


@pytest.mark.p1
@pytest.mark.webhooks
def test_webhook_unknown_order_makes_no_state_change(client, db_conn):
    """Rule 10: A webhook for an unknown order_id must not create any payment or subscription state."""
    unknown_order = "ord_does_not_exist_9999"
    res = client.send_webhook(
        order_id=unknown_order,
        provider_txn_id="txn_unknown",
        status="SUCCESS",
        signature="qa-secret",
    )
    # Service responds with 200 ignored
    assert res.status_code == 200
    assert res.json().get("status") == "ignored"

    # Invariant: No record in payments table
    p_count = db_conn.execute(
        "SELECT count(*) FROM payments WHERE order_id=?", (unknown_order,)
    ).fetchone()[0]
    assert p_count == 0

    # Invariant: No record in trials table
    t_count = db_conn.execute(
        "SELECT count(*) FROM trials WHERE order_id=?", (unknown_order,)
    ).fetchone()[0]
    assert t_count == 0


@pytest.mark.p1
@pytest.mark.webhooks
def test_webhook_invalid_status_rejected(client):
    """Rule 4: Provider statuses are PENDING, SUCCESS, and FAILED. Other statuses return 400."""
    res_trial = client.create_trial(user_id="heidi", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]

    res = client.send_webhook(
        order_id=order_id,
        provider_txn_id="txn_bad_status",
        status="AUTHORIZED",  # Invalid status
        signature="qa-secret",
    )
    assert res.status_code == 400
    assert res.json().get("error") == "invalid_request"
