import concurrent.futures
import threading
import pytest


@pytest.mark.p0
@pytest.mark.concurrency
@pytest.mark.bug
def test_concurrent_trial_creation_single_live_trial(client, db_conn):
    """Rule 14: Concurrent requests for the same user/plan must still respect the single-live-trial rule.

    Surfaces BUG-005.
    """
    user_id = "concurrent_user_01"
    plan = "yearly"
    amount = 99900
    concurrency_count = 5
    barrier = threading.Barrier(concurrency_count)

    def worker():
        barrier.wait()  # Synchronize start so all threads hit API simultaneously
        return client.create_trial(user_id=user_id, plan=plan, amount=amount)

    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency_count) as executor:
        futures = [executor.submit(worker) for _ in range(concurrency_count)]
        responses = [f.result() for f in futures]

    # Invariant: In the database, exactly 1 live trial must exist for this user and plan
    rows = db_conn.execute(
        "SELECT * FROM trials WHERE user_id=? AND plan=?", (user_id, plan)
    ).fetchall()
    assert len(rows) == 1, (
        f"[Rule 14 Violation] Concurrent requests created {len(rows)} duplicate live trials for user '{user_id}'! "
        f"Expected exactly 1 trial. (See BUGS.md - BUG-005)"
    )


@pytest.mark.p0
@pytest.mark.concurrency
@pytest.mark.bug
def test_concurrent_webhooks_race_condition(client, db_conn):
    """Rules 7 & 8: Concurrent duplicate webhook deliveries must not create duplicate payment records.

    Surfaces BUG-004.
    """
    res_trial = client.create_trial(user_id="conc_user_wh", plan="monthly", amount=29900)
    order_id = res_trial.json()["order_id"]
    txn_id = "txn_race_123"

    concurrency_count = 5
    barrier = threading.Barrier(concurrency_count)

    def worker():
        barrier.wait()
        return client.send_webhook(order_id=order_id, provider_txn_id=txn_id, status="SUCCESS")

    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency_count) as executor:
        futures = [executor.submit(worker) for _ in range(concurrency_count)]
        responses = [f.result() for f in futures]

    # Invariant: Exactly 1 payment record with txn_id in payments table
    rows = db_conn.execute("SELECT * FROM payments WHERE provider_txn_id=?", (txn_id,)).fetchall()
    assert len(rows) == 1, (
        f"[Rule 8 Violation] Concurrent webhook race condition created {len(rows)} duplicate payment records for '{txn_id}'! "
        f"Expected 1 record. (See BUGS.md - BUG-004)"
    )
