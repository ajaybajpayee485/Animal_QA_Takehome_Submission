# Test Strategy: Subscription & Payment Reliability

## 1. Executive Summary & Context

This test strategy defines the quality and reliability framework for Animall's subscription trial and asynchronous payment workflow. The system involves three distinct lifecycle phases:
1. **Trial Creation (`POST /api/trials`)**: User initiates a monthly or yearly trial starting in `PENDING` state.
2. **Asynchronous Payment Settlement (`POST /api/webhooks/payment`)**: Provider delivers webhooks (`SUCCESS`, `FAILED`, `PENDING`) with at-least-once delivery semantics, subject to network jitter, latency, duplicates, and out-of-order arrival.
3. **Internal Reconciliation (`POST /api/reconcile`)**: Scheduled batch/recovery process repairing drift between the payment provider and the internal subscription database.

Because subscriptions govern revenue and customer access, state corruption directly leads to double billing, unauthorized service access, or unjustified service revocation.

---

## 2. Core Business Risks & Impact Analysis

| Risk Category | Failure Mode / Threat | Business & Customer Impact | Severity |
| :--- | :--- | :--- | :--- |
| **Financial / Revenue** | Duplicate payments captured for the same order; multiple live trials billed simultaneously. | Customer disputes, chargebacks, payment gateway penalty fees, churn. | **Critical (P0)** |
| **Service Access / Trust** | Out-of-order webhook downgrades an `ACTIVE` trial to `FAILED` or `PENDING`. | Legitimate paying users abruptly lose access to premium features; high CS ticket volume. | **Critical (P0)** |
| **Security / Fraud** | Webhooks accepted without cryptographic signature verification (`X-Signature`). | Attackers forge `SUCCESS` callbacks to obtain free subscriptions without payment. | **Critical (P0)** |
| **State Drift / Latency** | Webhook dropped or delayed and reconciliation fails to heal `FAILED`/`PENDING` records. | Paying users remain stuck without access; reconciliation becomes useless. | **High (P1)** |
| **Concurrency / Contention** | Concurrent double-clicks or bot requests create duplicate live trials for same user/plan. | Inconsistent account state, split billing, corrupted user subscription history. | **High (P1)** |
| **Data Integrity** | Lack of DB constraints allows orphan payments, negative trial amounts, or null status. | Corrupted analytics, ledger imbalance, reporting errors. | **Medium (P2)** |

---

## 3. Risk-Based Scenario Classification (P0 / P1 / P2)

### Priority 0 (P0) — Blocker / Mission Critical
*These scenarios guard against revenue loss, security compromise, and customer lockout. Any failure blocks deployment.*

- **P0-1: Signature Verification**: Webhooks with missing, invalid, or forged `X-Signature` headers must return `HTTP 401` and make zero state changes.
- **P0-2: State Monotonicity (No Downgrade)**: A trial in `ACTIVE` state must **never** be downgraded by subsequent delayed or out-of-order `FAILED` or `PENDING` webhooks.
- **P0-3: Payment Idempotency & Unique Transaction**: Multiple deliveries of the same `provider_txn_id` must result in exactly one payment record and a single state transition.
- **P0-4: Reconciliation Healing**: If the provider reports `SUCCESS`, reconciliation must successfully recover records that are stuck in `PENDING` or prematurely marked `FAILED`.
- **P0-5: Single Live Trial Guarantee**: A user must never possess more than one live (`PENDING` or `ACTIVE`) trial for the same plan. Repeated requests must be rejected (e.g., 409 Conflict) or return the existing live trial safely.

### Priority 1 (P1) — High Priority
*These scenarios ensure operational stability, robust data contracts, and fault tolerance under load.*

- **P1-1: Concurrency Protection**: Burst requests (e.g., 5-10 parallel requests) for the same user and plan must race safely; exactly one live trial is created.
- **P1-2: Reconciliation Authorization**: `POST /api/reconcile` and `POST /api/admin/reset` must enforce `X-Internal-Key: qa-internal` and reject external callers with `HTTP 401`.
- **P1-3: Reconciliation Non-Destructive**: Reconciliation must be idempotent and must never downgrade an already `ACTIVE` trial.
- **P1-4: Unknown Order Handling**: Webhook callbacks referencing a non-existent `order_id` must not create orphan payments or corrupted trial rows.
- **P1-5: Positive Integer Amount Validation**: Trial amounts must be strictly positive integers (`amount > 0` in paise). Zero, negative integers, floats, and booleans must return `HTTP 400`.

### Priority 2 (P2) — Functional & Data Quality
*Edge cases, boundary checks, and API ergonomics.*

- **P2-1: Valid Plan Enumeration**: Plan creation only allows supported tiers (`monthly`, `yearly`). Unknown tiers return `HTTP 400`.
- **P2-2: Subscriptions Query Correctness**: `GET /api/subscriptions/{user_id}` must return the user's active/current trial and not be blinded by stale or pending records.
- **P2-3: Resilient Route Handling**: Trailing slashes and query parameters should be parsed safely without unintended 404s.
- **P2-4: Malformed Request Payloads**: Non-JSON payloads, empty request bodies, or missing mandatory fields return clean `HTTP 400` errors.

---

## 4. Deep-Dive Testing Dimensions

### 4.1. Asynchronous Events: Retries, Duplicates, and Out-of-Order
Real-world payment gateways guarantee at-least-once delivery; webhooks frequently arrive out of sequence due to network retries.
- **Test Strategy**:
  1. **Success then Delayed Failed**: Fire `SUCCESS` webhook -> verify trial is `ACTIVE`. Fire delayed `FAILED` webhook -> verify trial status **remains `ACTIVE`**.
  2. **Failed then Out-of-Order Success**: Fire `FAILED` webhook -> verify trial is `FAILED`. Fire delayed `SUCCESS` webhook -> verify trial transitions to `ACTIVE`.
  3. **Duplicate Webhook Delivery**: Fire `SUCCESS` webhook 3 consecutive times with identical `provider_txn_id`. Verify:
     - All return `HTTP 200`.
     - Exactly **one** row exists in `payments` for that `provider_txn_id`.
     - `trials.status` remains `ACTIVE`.

### 4.2. Concurrency & Race Conditions
When users double-tap on mobile or network retries fire concurrently:
- **Test Strategy**:
  1. **Parallel Trial Creation**: Fire 10 simultaneous threads attempting `POST /api/trials` with the same `(user_id, plan)`. Verify only 1 trial is created in the database.
  2. **Concurrent Webhooks**: Fire 5 concurrent threads delivering the same `(order_id, provider_txn_id)`. Verify database row locking prevents duplicate insertion in `payments`.

### 4.3. Reconciliation Strategy
Reconciliation is the automated safety net when webhooks fail or get dropped.
- **Test Strategy**:
  1. **Missed Webhook Recovery**: Create trial (remains `PENDING`). Simulate daily reconciliation job with `provider_status: SUCCESS`. Verify trial updates to `ACTIVE` and payment record is logged.
  2. **Premature Failure Recovery**: Trial marked `FAILED` due to a transient timeout. Provider confirms settlement was actually `SUCCESS`. Reconcile must recover status to `ACTIVE`.
  3. **Idempotency**: Running reconciliation 5 times on the same order must produce identical database state as running it once.

### 4.4. Data Integrity & Database Invariants
API status codes are insufficient; tests must inspect SQLite state directly:
- **Invariants to Assert**:
  - `trials.amount > 0`
  - `trials.status IN ('PENDING', 'ACTIVE', 'FAILED')`
  - Exactly $\le 1$ record in `trials` where `user_id = ? AND plan = ? AND status IN ('PENDING', 'ACTIVE')`
  - `payments.provider_txn_id` must be unique across all rows.
  - Every `payments.order_id` must reference an existing `trials.order_id`.

### 4.5. Security & Authorization
- **Webhook Spoofing**: Validate that `/api/webhooks/payment` rejects requests with missing `X-Signature` or incorrect values (e.g., `wrong-secret`) with `401 Unauthorized`.
- **Internal API Protection**: Verify `/api/reconcile` and `/api/admin/reset` cannot be invoked without `X-Internal-Key: qa-internal`.
- **Injection / Malformed Input**: Verify SQL injection strings in `user_id` or `order_id` do not cause database syntax errors or unauthorized queries.

---

## 5. Automation vs. Manual Testing Matrix

| Testing Scope | Automated vs. Manual | Rationale |
| :--- | :--- | :--- |
| **API Functional & Edge Cases** | **100% Automated** | Fast feedback in CI; predictable input/output contracts. |
| **Out-of-order & Duplicate Webhooks** | **100% Automated** | Impossible to reproduce consistently by hand; requires scripted sequences. |
| **Concurrency / Race Conditions** | **100% Automated** | Requires multi-threaded execution within milliseconds. |
| **Reconciliation Logic** | **100% Automated** | Deterministic batch verification against DB states. |
| **Gateway Network Timeouts & Resiliency** | **Automated (WireMock / Chaos)** | Injecting socket drops, 502/504 gateway timeouts via mock server. |
| **Payment Gateway Sandbox UI Verification** | **Manual / Exploratory** | Verifying third-party hosted checkout screens, 3D Secure OTP flows, browser redirects. |
| **Cross-Device UI Sync** | **Manual / Exploratory** | Verifying app UI displays active subscription badge immediately after webhook processing. |

---

## 6. Post-Production Monitoring & Observability

To catch discrepancies before users report them, deploy the following telemetry:

### 1. Key Metrics & Slos
- `subscription_activation_success_rate`: Ratio of successful activations to total payment attempts (Target: > 99.5%).
- `webhook_delivery_latency`: Time elapsed between provider event timestamp and webhook ingestion (Alert if p95 > 10s).
- `reconciliation_drift_count`: Number of records healed per reconciliation run. Sustained spike indicates webhook delivery pipeline outage.
- `duplicate_webhook_rate`: Frequency of duplicate callback arrivals (early warning of provider retry storms).

### 2. High-Severity Alerts (PagerDuty / Slack)
- **CRITICAL: Webhook Signature Failure Spike**: More than 5 failed signature checks in 5 minutes indicates key misconfiguration or active attack.
- **CRITICAL: Stuck Pending Trials**: Any trial remaining in `PENDING` for $> 30$ minutes without a webhook or reconciliation attempt.
- **CRITICAL: Downgrade Attempt Detected**: Log metric fired whenever an incoming webhook tries to change an `ACTIVE` subscription to `FAILED`.
- **HIGH: Reconciliation Anomaly**: Reconciler encounters order where provider status is `SUCCESS` but bank settlement is missing.
